let humerus;

function preload(){
 humerusImg=loadImage('humerus.png');  
}

function setup() {
  createCanvas(500, 500);
  humerus = new humerusDraggable();
}

function draw() {
  background(255);
  humerus.drag();
  humerus.hoverOver();
  humerus.show();
}

function mousePressed() {
  humerus.pressed();
}

function mouseReleased() {
  // Quit dragging
  humerus.released();
}