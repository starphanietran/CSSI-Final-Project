
class humerusDraggable {
  
  constructor() {
    //humerus image position and dimensions
    this.x = 100;
    this.y = 100;
    this.width = 30;
    this.height = 100;
    this.dragging = false; // Is the object being dragged?
    this.over = false; // Is the mouse hovering over the humerus?   
  }

  hoverOver() {
    // Is mouse hovering over object
    if (mouseX > this.x && mouseX < this.x + this.width && mouseY > this.y && mouseY < this.y + this.height) {
      this.over = true;
    } else {
      this.over = false;
    }
  }

  drag() {
    // Drags image to new location based on mouse --> no idea what's going on lmao???
    if (this.dragging) {
      this.x = mouseX + this.offsetX;
      this.y = mouseY + this.offsetY;
    }
  }

  show() {
    stroke(0);
    // Different tint based on state
    if (this.dragging) {
      tint(220);
    } else if (this.over) {
      tint(150);
    } else {
      noTint();
    }
    image(humerusImg,this.x, this.y, this.width, this.height);
  }

  pressed() {
    // Is the humerus selected/pressed on
    if (mouseX > this.x && mouseX < this.x + this.width && mouseY > this.y && mouseY < this.y + this.height) {
      this.dragging = true;
      // If so, keep track of relative location of click to corner of humerus image --> what's this ???
      this.offsetX = this.x - mouseX;
      this.offsetY = this.y - mouseY;
    }
  }

  released() {
    // Quit dragging
    this.dragging = false;
  }
}